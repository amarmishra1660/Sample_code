import { Component, OnInit } from '@angular/core';
import { FormsModule }   from '@angular/forms';

@Component({
  selector: 'app-neha-com',
  templateUrl: './neha-com.component.html',
  styleUrls: ['./neha-com.component.css']
})
export class NehaComComponent implements OnInit {

  servercreation = "you have not yet created any server";
  ServerName = "server";
  serverCreated = false;
  newColor = true;
  toggle = true;
  status = "Enable";
  students:any[] = [
    { name : 'amar'},
    { name : 'neha'},
    { name : 'pallavi'},
    { name : 'ashish'}
  ];
  

  constructor() { }

  ngOnInit(): void {
  }

  ChangeClor(){

    this.serverCreated = true;
    this.servercreation = this.ServerName + '  was created';
  }

  ChangeColour(){
    return this.newColor = !this.newColor;


  }

  getData(event:Event){
    //this.ServerName = event.target.value;
    this.ServerName = (<HTMLInputElement>event.target).value;

  }

  enableDisableRule() {
    this.toggle = !this.toggle;
    this.status = this.toggle ? "Enable" : "Disable";

}



}
