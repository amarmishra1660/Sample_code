import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes,RouterModule} from '@angular/router';

import { AppComponent } from './app.component';
import { SuccessAlert } from './SuccessAlert/SuccessAlert.component';
import { WarningAlert } from './WarningAlert/WarningAlert.component';
import { NehaComComponent } from './neha-com/neha-com.component';
import { HomeComponent } from './home/home.component';

const appRoutes: Routes = [
  { path: 'home', 
    component:HomeComponent,
      children: [                          //<---- child components declared here
        {
            path:'success',
            component:SuccessAlert
        },
    ]
  
  },
  { path: 'success', component:SuccessAlert},
  { path: 'warning', component:WarningAlert},
  { path: 'neha', component:NehaComComponent},
];

@NgModule({
  declarations: [
    AppComponent,
    SuccessAlert,
    WarningAlert,
    NehaComComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
