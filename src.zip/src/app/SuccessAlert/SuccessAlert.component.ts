import { Component } from '@angular/core';

@Component({
    selector: 'app-success',
    templateUrl: './SuccessAlert.component.html'
})
export class SuccessAlert{


}

